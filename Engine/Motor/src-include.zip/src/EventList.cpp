#include "..\include\EventList.h"
#include "..\include\GamePad.h"

bool EventList::Callback()
{
	switch (type)
	{
		case 1:
			cout << "soy 1\n";
			return true;
			break;
		case 2:
			cout << "soy 2\n";
			return false;
			break;
		case 3:
			cout << "soy 3\n";
			return true;
			break;
	}
}
