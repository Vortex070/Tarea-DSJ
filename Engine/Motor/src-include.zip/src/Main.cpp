#include "..\include\InputManager.h"

void StartUp()
{
	
}

void main(void)
{	
	//StartUp();
	InputManager *input = new InputManager();
	input->Start();
	input->Run();

}