#include "..\include\InputManager.h"


InputManager InputManager::Start()
{
	Listener();
	start = true;

	return InputManager();
}

InputManager InputManager::Run()
{
	GamePad gamepad;

	bool wasConnected = true;

	while (start == true)
	{
		

		Sleep(100);

		if (!gamepad.Refresh())
		{
			if (wasConnected)
			{
				wasConnected = false;

				cout << "Please connect an Xbox 360 controller." << endl;
			}
		}
		else
		{
			if (!wasConnected)
			{
				wasConnected = true;

				cout << "Controller connected on port " << gamepad.GetPort() << endl;
			}

			//cout << "Left thumb stick: (" << gamepad.leftStickX << ", " << gamepad.leftStickY << ")   Right thumb stick : (" << gamepad.rightStickX << ", " << gamepad.rightStickY << ")" << endl;

			//cout << "Left analog trigger: " << gamepad.leftTrigger << "   Right analog trigger: " << gamepad.rightTrigger << endl;

			if (gamepad.IsPressed(XINPUT_GAMEPAD_A))
			{
				Events(1);
				Tail.push(1);

				cout << "(A) button pressed" << endl;
			}

			if (gamepad.IsPressed(XINPUT_GAMEPAD_B))
			{
				Events(2);
				Tail.push(2);

				cout << "(B) button pressed" << endl;
			}

			while (!Tail.empty())
			{
				qTemp = Tail.front();
				Tail.pop();
				for (list<EventList>::iterator it = List.begin(); 
				it != List.end(); ++it)
				{
					if (qTemp.type == it->type)
					{
						cout << qTemp.type << ", " << it->type << endl;

						if (it->Callback() == true)
						{
							it = List.end();
						}//if
					}//if
				}//for
			}//dispatcher
		}//xinput
	}
	return InputManager();//666
}

InputManager InputManager::ShutDown()
{
	return InputManager();
}

InputManager InputManager::Listener()
{
	//ask game state

	//create listener depending on game state

	//for (eType; eType < 4; eType++)
	//{
		//EventList(eType);
		//List.push_front(eType);
	//}

	//List.push_front(1);
	List.push_front(3);
	List.push_front(2);
	List.push_front(1);
	return InputManager();
}

InputManager InputManager::Dispatcher()
{

	return InputManager();
}
