#pragma once
class Events
{
public:
	int type;
	Events(int Itype){
		type = Itype;
	}

	Events() {}
};

