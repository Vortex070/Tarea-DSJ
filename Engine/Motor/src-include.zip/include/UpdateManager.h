#pragma once

class UpdateManager
{
public:
	static UpdateManager instance()
	{
		static UpdateManager *instance = new UpdateManager();
		return *instance;
	}

	static UpdateManager Run();
	static UpdateManager ShutDown();

private:
	UpdateManager() {}

};